document.getElementById("heading").innerHTML = "PROTECT OUR WILD LIFE";
document.getElementById("heading").style.color ="purple";
document.getElementById("heading").style.fontSize="100px";

document.getElementById("paragraph").innerHTML = "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, odio fuga esse aliquid tempora voluptatibus alias aperiam quia dolorum totam eligendi quo corporis, architecto doloremque ea id consectetur, sed nostrum?Lorem ipsum dolor, sit amet consectetur adipisicing elit. Reiciendis ad laboriosam quos laborum totam magni, repellendus quidem aspernatur fuga, commodi, ab accusantium sint tempore minima! Esse itaque necessitatibus iusto ipsum incidunt doloribus placeat minus mollitia consequatur est architecto blanditiis earum dolorum nobis, voluptate vitae omnis, ea possimus cumque amet non! Delectus amet harum vitae magnam molestiae? Dolorem ipsam quod ratione eum quae ipsa saepe magnam explicabo architecto porro aperiam, non vitae rem nihil est. Molestiae suscipit tempora tenetur doloremque inventore possimus ipsum illo velit ipsa, assumenda cum odit dolor reprehenderit maiores facere explicabo quisquam ex natus nam vel asperiores nemo.";
document.getElementById("paragraph").style.fontSize="18px";
document.getElementById("paragraph").style.color="olive";
document.getElementById("paragraph").style.border="solid gray";

document.body.style.backgroundColor = "#C0C0C0";




